#include <iostream>
#include<iomanip>
#include<vector>
#include"projet.h"
using namespace std;
int main()
{
    stat Stat;
    Stat.affiche_premier_plan();
    return 0;
}
